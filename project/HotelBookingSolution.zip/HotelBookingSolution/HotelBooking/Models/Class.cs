﻿namespace HotelBooking.Models
{
    public class Class
    {
    }
}
